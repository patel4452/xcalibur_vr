﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'gu', {
	button: 'પેસ્ટ (ટેક્સ્ટ)',
	title: 'પેસ્ટ (ટેક્સ્ટ)'
} );
